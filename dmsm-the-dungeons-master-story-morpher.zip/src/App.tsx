/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from "react";
import Markdown from "react-markdown";
import { Upload, Wand2, Loader2, BookOpen, Mic, Volume2, Square } from "lucide-react";

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export default function App() {
  const [story, setStory] = useState("");
  const [ruleset, setRuleset] = useState("dnd2024");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setError("File exceeds the 10MB limit.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result;
      if (typeof text === "string") {
        setStory(text);
        setError(null);
      }
    };
    reader.readAsText(file);
  };
  
  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Speech Recognition not supported in this browser.");
      return;
    }
    
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    
    recognition.onresult = (event: any) => {
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript + ' ';
        }
      }
      if (finalTranscript) {
        setStory((prev) => prev + finalTranscript);
      }
    };
    
    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      setIsRecording(false);
    };
    
    recognition.onend = () => {
      setIsRecording(false);
    };
    
    recognition.start();
    recognitionRef.current = recognition;
    setIsRecording(true);
  };

  const handleTTS = async () => {
    if (!result) return;
    if (isPlaying && audioRef.current) {
       audioRef.current.pause();
       setIsPlaying(false);
       return;
    }
    
    try {
       setIsPlaying(true);
       const res = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: result }),
       });
       const data = await res.json();
       if (!res.ok) throw new Error(data.error);
       
       const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
       audioRef.current = audio;
       audio.onended = () => setIsPlaying(false);
       audio.play();
    } catch (err: any) {
       console.error("TTS Error:", err);
       alert("Failed to generate speech: " + err.message);
       setIsPlaying(false);
    }
  };

  const handleGenerate = async () => {
    if (!story.trim()) return;

    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/morph-story", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ story, ruleset }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to generate DM Guide");
      }

      setResult(data.result);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 p-6 flex flex-col font-sans selection:bg-red-900 selection:text-red-100">
      <div className="max-w-[1200px] w-full mx-auto flex flex-col flex-grow">
        
        {/* Header Section */}
        <header className="flex justify-between items-center mb-6 flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center shadow-lg shadow-red-900/20">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white uppercase">DMSM The Dungeons Master Story Morpher</h1>
              <p className="text-xs text-slate-500 font-mono tracking-widest hidden sm:block">v1.2.0-STABLE / REPO: DM-AUTO-MORPH</p>
            </div>
          </div>
          <div className="flex space-x-4">
            <div className="hidden md:flex items-center bg-slate-900 px-3 py-1.5 rounded-full border border-slate-800">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
              <select 
                value={ruleset} 
                onChange={(e) => setRuleset(e.target.value)}
                className="bg-transparent text-[10px] sm:text-xs font-medium uppercase text-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="dnd2024" className="bg-slate-900">SYSTEM: D&D 2024 (LATEST)</option>
                <option value="dnd5e" className="bg-slate-900">SYSTEM: D&D 5E (2014)</option>
                <option value="dnd4e" className="bg-slate-900">SYSTEM: D&D 4E</option>
              </select>
            </div>
            <button
              onClick={handleGenerate}
              disabled={loading || !story.trim()}
              className="bg-white text-black px-4 py-1.5 rounded-lg text-sm font-bold shadow-xl hover:bg-slate-200 disabled:opacity-50 transition-colors flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
              <span>{loading ? 'MORPHING' : 'GENERATE'}</span>
            </button>
          </div>
        </header>

        {/* Bento Grid Main Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-grow pb-6 min-h-0">
          
          {/* Story Input (Source) */}
          <div className="lg:col-span-4 bg-slate-900/50 border border-slate-800 rounded-2xl p-5 flex flex-col min-h-[350px]">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-xs font-bold uppercase text-slate-500 tracking-tighter">RAW NARRATIVE SOURCE</h2>
              <div className="flex gap-2">
                <button
                  onClick={toggleRecording}
                  className={`text-[10px] px-2 py-1 rounded flex items-center gap-1 transition-colors cursor-pointer ${isRecording ? 'bg-red-900/50 text-red-400 border border-red-900/50 animate-pulse' : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700'}`}
                >
                  {isRecording ? <Square className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
                  <span>{isRecording ? 'RECORDING' : 'DICTATE'}</span>
                </button>
                <div>
                  <input 
                    type="file" 
                    accept=".txt,.md" 
                    className="hidden" 
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                  />
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="text-[10px] bg-slate-800 text-slate-400 px-2 py-1 rounded flex items-center gap-1 hover:text-slate-200 hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    <Upload className="w-3 h-3" />
                    <span>UPLOAD .TXT</span>
                  </button>
                </div>
              </div>
            </div>
            <textarea
              value={story}
              onChange={(e) => setStory(e.target.value)}
              placeholder="Paste your story here, or upload a .txt/.md file (Max 10MB)..."
              className="flex-grow w-full bg-transparent border-none font-serif italic text-slate-400 text-sm leading-relaxed focus:outline-none resize-none custom-scrollbar"
            />
            
            {loading && (
              <div className="mt-4 p-3 bg-red-900/10 border border-red-900/30 rounded-xl flex-shrink-0">
                <p className="text-[10px] text-red-400 uppercase font-bold mb-1">Morphing Engine Active</p>
                <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-red-500 w-[85%] animate-pulse"></div>
                </div>
              </div>
            )}
            
            {error && (
              <div className="mt-4 p-3 bg-red-900/10 border border-red-900/30 rounded-xl flex-shrink-0">
                <p className="text-[10px] text-red-400 uppercase font-bold mb-1">Engine Error</p>
                <p className="text-xs text-red-300">{error}</p>
              </div>
            )}
          </div>

          {/* DM Section / Procedures */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col shadow-inner min-h-[400px]">
            <div className="flex items-center space-x-2 mb-4">
              <div className="px-2 py-1 bg-blue-500 text-[10px] font-bold text-white rounded uppercase flex items-center gap-2">
                <span>Dungeon Master's Guide</span>
                {result && (
                  <button 
                    onClick={handleTTS}
                    disabled={isPlaying && !audioRef.current}
                    className="ml-2 bg-blue-600 hover:bg-blue-700 px-1.5 py-0.5 rounded transition-colors flex items-center gap-1"
                    title="Read aloud with Gemini TTS"
                  >
                    {isPlaying ? <Square className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                  </button>
                )}
              </div>
              <div className="h-[1px] flex-grow bg-slate-800"></div>
            </div>
            
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
              {result ? (
                <div className="prose prose-sm prose-invert max-w-none prose-headings:text-slate-200 prose-a:text-blue-400 prose-strong:text-slate-200 prose-code:text-amber-400 prose-pre:bg-slate-950 prose-pre:border prose-pre:border-slate-800">
                  <Markdown>{result}</Markdown>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-6 max-w-lg mx-auto text-center p-6">
                  <div className="w-16 h-16 bg-slate-800/50 rounded-2xl flex items-center justify-center border border-slate-700/50 mb-2">
                    <BookOpen className="w-8 h-8 text-blue-500" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-slate-200">Welcome to DMSM The Dungeons Master Story Morpher</h3>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      This tool transforms any raw story, narrative concept, or scattered notes into a highly structured Dungeon Master's guide formatted for your selected ruleset.
                    </p>
                    <p className="text-sm text-slate-400 leading-relaxed italic mt-2">
                      Note: This tool is designed to help Dungeon Masters understand the rules and concepts of D&D and to better frame their stories. It is not meant to replace Dungeon Masters, but rather to teach them storytelling and player engagement.
                    </p>
                  </div>
                  <div className="w-full bg-slate-950/50 border border-slate-800 rounded-xl p-5 text-left space-y-3 mt-4 shadow-inner">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-4">Quick Start Guide</h4>
                    <ul className="text-sm space-y-4 text-slate-300">
                      <li className="flex items-start gap-3">
                        <span className="text-blue-500 font-bold">1.</span>
                        <span><strong>Input your story:</strong> Type, dictate via the microphone, or upload a text file (<code>.txt</code> or <code>.md</code>). <span className="text-slate-500 italic text-xs block mt-1">Max file size: 10MB.</span></span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-blue-500 font-bold">2.</span>
                        <span><strong>Select ruleset:</strong> Choose between D&D 2024, 5e, or 4e from the top navigation bar.</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-blue-500 font-bold">3.</span>
                        <span><strong>Morph:</strong> Click <strong>Generate</strong> to instantly build scenes, DC checks, and player prompts.</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-blue-500 font-bold">4.</span>
                        <span><strong>Listen:</strong> Click the speaker icon on the generated guide to have the AI read it aloud.</span>
                      </li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Footer Bar */}
        <footer className="flex justify-between items-center text-[10px] text-slate-600 font-mono uppercase tracking-widest flex-shrink-0">
          <div className="flex space-x-6">
            <span>Session: Auto-Morpher</span>
            <span>Status: Online</span>
          </div>
          <div className="hidden sm:block">
            CONNECTED TO DM-AUTO-MORPH ENGINE
          </div>
        </footer>
      </div>
    </div>
  );
}
