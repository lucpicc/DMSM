import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import * as dotenv from "dotenv";

dotenv.config();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json({ limit: "10mb" }));

  // API Routes
  app.post("/api/morph-story", async (req, res) => {
    try {
      const { story, ruleset = "dnd2024" } = req.body;
      
      if (!story) {
        return res.status(400).json({ error: "Story content is required." });
      }

      let systemRules = "D&D 2024 (5e)";
      let rulesInstructions = "Explicit D&D 2024 rules-compliant skill checks or saving throws, clearly stating exactly which dice and how many to roll (e.g., 'Roll 1d20 + Strength modifier' or 'Roll 2d6 for damage')";
      let coreRules = "";

      if (ruleset === "dnd5e") {
        systemRules = "D&D 5e (2014)";
        rulesInstructions = "Explicit D&D 5e (2014) rules-compliant skill checks or saving throws, clearly stating exactly which dice and how many to roll (e.g., 'Roll 1d20 + Strength modifier' or 'Roll 2d6 for damage')";
        coreRules = `CORE RULES SUMMARY (D&D 5e 2014):
- Ability Scores: STR, DEX, CON, INT, WIS, CHA.
- Core Mechanic: d20 + Ability Modifier + Proficiency Bonus vs DC.
- Advantage/Disadvantage: Roll 2d20, keep highest/lowest.
- Skills: Athletics, Acrobatics, Stealth, Arcana, History, Investigation, Nature, Religion, Insight, Perception, Survival, Deception, Intimidation, Persuasion.
- Saving Throws: Dodge effects (spells, traps).
- Combat: Movement, Action, Bonus Action.
- Actions: Attack, Cast Spell, Dash, Disengage, Dodge, Hide.`;
      } else if (ruleset === "dnd4e") {
        systemRules = "D&D 4e";
        rulesInstructions = "Explicit D&D 4e rules-compliant skill checks, defenses, or saving throws, clearly stating exactly which dice and how many to roll (e.g., 'Roll 1d20 + Dexterity modifier' or 'Roll 2d8 for damage')";
        coreRules = `CORE RULES SUMMARY (D&D 4e):
- Core Mechanic: d20 + 1/2 Level + Ability Modifiers vs Defense.
- Defenses: AC, Fortitude, Reflex, Will (attacks target these).
- Saving Throws: A flat d20 roll (10+ succeeds) at the end of turn to end ongoing effects.
- Powers: At-Will, Encounter, Daily.
- Skills: Acrobatics, Arcana, Athletics, Bluff, Diplomacy, Dungeoneering, Endurance, Heal, History, Insight, Intimidate, Nature, Perception, Religion, Stealth, Streetwise, Thievery.
- Combat: Standard, Move, Minor actions.`;
      } else {
        systemRules = "D&D 2024 (5e)";
        rulesInstructions = "Explicit D&D 2024 rules-compliant skill checks or saving throws, clearly stating exactly which dice and how many to roll (e.g., 'Roll 1d20 + Strength modifier' or 'Roll 2d6 for damage')";
        coreRules = `CORE RULES SUMMARY (D&D 2024):
- Core mechanics: d20 + Ability Modifier + Proficiency Bonus.
- Weapon Masteries: Cleave, Graze, Nick, Push, Sap, Slow, Topple, Vex.
- Heroic Inspiration: Reroll any die (only hold one).
- Exhaustion: 1 to 6 levels, cumulative -2 penalty to d20 tests.
- Actions: Magic action, Utilize action. Potions take a Bonus Action.
- Surprised condition: Disadvantage on Initiative.`;
      }

      const prompt = `You are an expert Dungeon Master for ${systemRules}. I will provide you with a story or adventure concept.
Your task is to 'morph' this story into a highly structured Dungeon Master's guide.

Use the following core rules to ensure accuracy in your mechanics generation:
${coreRules}

For the provided story, please generate the following:
1. **Overview & Setup**: A brief introduction to the adventure.
2. **Scenes / Rooms**: Break the story down into distinct scenes or rooms. For each scene include:
   - **Boxed Text**: What the DM reads out loud to the players.
   - **DM Notes**: Hidden information and motivations.
   - **Required Rolls & Checks**: ${rulesInstructions} needed in the scene. Whenever you specify a DC, you MUST explicitly define what DC stands for ("Difficulty Class") and explain what that specific DC represents in this instance (e.g., "The DC (Difficulty Class) is 15, which represents the thickness of the heavy wooden door").
   - **Questions/Prompts for Players**: What the DM should ask the players to keep the action moving.
3. **Important Mechanics**: Any overarching rules, encounters, or specific procedures to follow.

Format the entire response in clean Markdown.

Here is the story:
"""
${story}
"""`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          systemInstruction: `You are an expert ${systemRules} Dungeon Master. Respond only in well-formatted Markdown.`,
        },
      });

      res.json({ result: response.text });
    } catch (error) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate DM guide." });
    }
  });

  app.post("/api/transcribe", async (req, res) => {
    try {
      const { audioBase64, mimeType } = req.body;
      if (!audioBase64 || !mimeType) {
        return res.status(400).json({ error: "Audio data is required." });
      }
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          { inlineData: { data: audioBase64, mimeType } },
          { text: "Please transcribe this audio exactly as spoken. Output only the transcription, no additional text." }
        ]
      });
      
      res.json({ text: response.text });
    } catch (error) {
      console.error("Transcribe Error:", error);
      res.status(500).json({ error: "Failed to transcribe audio." });
    }
  });

  app.post("/api/tts", async (req, res) => {
    try {
      const { text } = req.body;
      if (!text) {
         return res.status(400).json({ error: "Text is required." });
      }

      // Using gemini-2.5-flash for TTS
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ parts: [{ text }] }],
        config: {
          // @ts-ignore - The types might not have AUDIO modality yet depending on version, but it's valid
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Charon' }
            }
          }
        }
      });
      
      const audioBase64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (audioBase64) {
        res.json({ audioBase64 });
      } else {
        res.status(500).json({ error: "No audio generated." });
      }
    } catch (error) {
      console.error("TTS Error:", error);
      res.status(500).json({ error: "Failed to generate speech." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Error starting server:", err);
});
